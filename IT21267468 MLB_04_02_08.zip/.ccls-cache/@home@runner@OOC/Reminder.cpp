#include"Reminder.h"
#include <iostream>
#include <cstring>
using namespace std;

Reminder::Reminder(){
	userID=0;
	strcpy(ReminderTopic,"");
	strcpy(AboutReminder,"");
}

char Reminder::SendReminder(int userID, char Topic[], char About[]){
	userID=0;
	strcpy(ReminderTopic,Topic);
	strcpy(AboutReminder,About);
}